/* eslint-disable */
import * as types from './graphql';
import type { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';

/**
 * Map of all GraphQL operations in the project.
 *
 * This map has several performance disadvantages:
 * 1. It is not tree-shakeable, so it will include all operations in the project.
 * 2. It is not minifiable, so the string of a GraphQL query will be multiple times inside the bundle.
 * 3. It does not support dead code elimination, so it will add unused operations.
 *
 * Therefore it is highly recommended to use the babel or swc plugin for production.
 * Learn more about it here: https://the-guild.dev/graphql/codegen/plugins/presets/preset-client#reducing-bundle-size
 */
type Documents = {
    "\n  query GetTitle($id: UUID) {\n    mysqlTitles(where: { titleId: { eq: $id } }) {\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        isAdult\n        startYear\n        endYear\n        runtimeMinutes\n        titleType\n        genresGenre {\n          genreId\n          genre\n        }\n      }\n    }\n  }\n": typeof types.GetTitleDocument,
    "\n  mutation EditTitle($id: UUID!, $title: TitlesDtoInput!) {\n    updateMysqlTitle(input: { id: $id, title: $title }) {\n      titles {\n        endYear\n        isAdult\n        originalTitle\n        primaryTitle\n        runtimeMinutes\n        startYear\n        titleId\n        titleType\n      }\n      errors {\n        ... on Error {\n          message\n        }\n      }\n    }\n  }\n": typeof types.EditTitleDocument,
    "\n  query GetTitles($skip: Int, $take: Int) {\n    mysqlTitles(skip: $skip, take: $take, order: { startYear: DESC }) {\n      totalCount\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        startYear\n      }\n    }\n  }\n": typeof types.GetTitlesDocument,
};
const documents: Documents = {
    "\n  query GetTitle($id: UUID) {\n    mysqlTitles(where: { titleId: { eq: $id } }) {\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        isAdult\n        startYear\n        endYear\n        runtimeMinutes\n        titleType\n        genresGenre {\n          genreId\n          genre\n        }\n      }\n    }\n  }\n": types.GetTitleDocument,
    "\n  mutation EditTitle($id: UUID!, $title: TitlesDtoInput!) {\n    updateMysqlTitle(input: { id: $id, title: $title }) {\n      titles {\n        endYear\n        isAdult\n        originalTitle\n        primaryTitle\n        runtimeMinutes\n        startYear\n        titleId\n        titleType\n      }\n      errors {\n        ... on Error {\n          message\n        }\n      }\n    }\n  }\n": types.EditTitleDocument,
    "\n  query GetTitles($skip: Int, $take: Int) {\n    mysqlTitles(skip: $skip, take: $take, order: { startYear: DESC }) {\n      totalCount\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        startYear\n      }\n    }\n  }\n": types.GetTitlesDocument,
};

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 *
 *
 * @example
 * ```ts
 * const query = graphql(`query GetUser($id: ID!) { user(id: $id) { name } }`);
 * ```
 *
 * The query argument is unknown!
 * Please regenerate the types.
 */
export function graphql(source: string): unknown;

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "\n  query GetTitle($id: UUID) {\n    mysqlTitles(where: { titleId: { eq: $id } }) {\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        isAdult\n        startYear\n        endYear\n        runtimeMinutes\n        titleType\n        genresGenre {\n          genreId\n          genre\n        }\n      }\n    }\n  }\n"): (typeof documents)["\n  query GetTitle($id: UUID) {\n    mysqlTitles(where: { titleId: { eq: $id } }) {\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        isAdult\n        startYear\n        endYear\n        runtimeMinutes\n        titleType\n        genresGenre {\n          genreId\n          genre\n        }\n      }\n    }\n  }\n"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "\n  mutation EditTitle($id: UUID!, $title: TitlesDtoInput!) {\n    updateMysqlTitle(input: { id: $id, title: $title }) {\n      titles {\n        endYear\n        isAdult\n        originalTitle\n        primaryTitle\n        runtimeMinutes\n        startYear\n        titleId\n        titleType\n      }\n      errors {\n        ... on Error {\n          message\n        }\n      }\n    }\n  }\n"): (typeof documents)["\n  mutation EditTitle($id: UUID!, $title: TitlesDtoInput!) {\n    updateMysqlTitle(input: { id: $id, title: $title }) {\n      titles {\n        endYear\n        isAdult\n        originalTitle\n        primaryTitle\n        runtimeMinutes\n        startYear\n        titleId\n        titleType\n      }\n      errors {\n        ... on Error {\n          message\n        }\n      }\n    }\n  }\n"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "\n  query GetTitles($skip: Int, $take: Int) {\n    mysqlTitles(skip: $skip, take: $take, order: { startYear: DESC }) {\n      totalCount\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        startYear\n      }\n    }\n  }\n"): (typeof documents)["\n  query GetTitles($skip: Int, $take: Int) {\n    mysqlTitles(skip: $skip, take: $take, order: { startYear: DESC }) {\n      totalCount\n      items {\n        titleId\n        primaryTitle\n        originalTitle\n        startYear\n      }\n    }\n  }\n"];

export function graphql(source: string) {
  return (documents as any)[source] ?? {};
}

export type DocumentType<TDocumentNode extends DocumentNode<any, any>> = TDocumentNode extends DocumentNode<  infer TType,  any>  ? TType  : never;