namespace EfCoreModelsLib.Models.Neo4J.Neo4JModels
{
    public partial class GenresEntity
    {
        public Guid GenreId { get; set; }
        public string Genre { get; set; } = "";
    }
}