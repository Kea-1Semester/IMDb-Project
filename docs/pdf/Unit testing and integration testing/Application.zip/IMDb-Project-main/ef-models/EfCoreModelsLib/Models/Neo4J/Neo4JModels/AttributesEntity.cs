namespace EfCoreModelsLib.Models.Neo4J.Neo4JModels
{
    public partial class AttributesEntity
    {
        public Guid AttributeId { get; set; }
        public string Attribute { get; set; } = "";
    }
}