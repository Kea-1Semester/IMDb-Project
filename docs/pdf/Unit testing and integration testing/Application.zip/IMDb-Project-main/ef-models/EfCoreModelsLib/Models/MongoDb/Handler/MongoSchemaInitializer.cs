﻿using System.Collections.Concurrent;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EfCoreModelsLib.Models.MongoDb.Handler
{
    /// <summary>
    /// Utility for ensuring MongoDB collection schema and indexes.
    /// </summary>
    public static class MongoSchemaInitializer<T>
    {
        private static readonly ConcurrentDictionary<string, MongoClient> _clients = new();

        private static MongoClient GetOrCreateClient(string connectionString) =>
            _clients.GetOrAdd(connectionString, connStr => new MongoClient(connStr));

        /// <summary>
        /// Ensures the collection exists with the specified schema and indexes.
        /// </summary>
        public static async Task EnsureCollectionSchema(
            string connectionString,
            string databaseName,
            string collectionName,
            BsonDocument schema,
            IEnumerable<BsonDocument>? compoundIndex = null,
            BsonDocument? singleFieldIndex = null,
            CancellationToken cancellationToken = default
        )
        {
            var client = GetOrCreateClient(connectionString);
            var database = client.GetDatabase(databaseName);


            if (database != null)
            {
                var collectionList = await (await database.ListCollectionNamesAsync(cancellationToken: cancellationToken)).ToListAsync(cancellationToken);
                if (!collectionList.Contains(collectionName))
                {
                    var options = new CreateCollectionOptions<BsonDocument>()
                    {
                        Validator = new BsonDocumentFilterDefinition<BsonDocument>(schema)
                    };
                    await database.CreateCollectionAsync(collectionName, options, cancellationToken);

                    Console.WriteLine($"Created collection '{collectionName}' with schema validation.");
                }
                else
                {
                    var command = new BsonDocument
                        {
                            { "collMod", collectionName },
                            { "validator", schema }
                        };
                    await database.RunCommandAsync<BsonDocument>(command, cancellationToken: cancellationToken);
                }
            }

            if (compoundIndex != null && compoundIndex.Any())
            {
                var collection = database?.GetCollection<T>(collectionName);
                var indexes = compoundIndex
                    .Select(indexDoc =>
                        new CreateIndexModel<T>(new BsonDocumentIndexKeysDefinition<T>(indexDoc)))
                    .ToList();

                await collection?.Indexes.CreateManyAsync(indexes, cancellationToken)!;

                Console.WriteLine($"Ensured indexes on collection '{collectionName}'.");

            }
            if (singleFieldIndex != null)
            {
                var collection = database?.GetCollection<T>(collectionName);
                var indexModel = new CreateIndexModel<T>(new BsonDocumentIndexKeysDefinition<T>(singleFieldIndex));
                await collection?.Indexes.CreateOneAsync(indexModel, cancellationToken: cancellationToken)!;

                Console.WriteLine($"Ensured single field index on collection '{collectionName}'.");
            }
        }
    }
}

