namespace EfCoreModelsLib.Models.Neo4J.Neo4JModels
{
    public partial class TypesEntity
    {
        public Guid TypeId { get; set; }
        public string Type { get; set; } = "";
    }
}