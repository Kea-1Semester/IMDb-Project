namespace EfCoreModelsLib.Models.Neo4J.Neo4JModels
{
    public partial class ProfessionsEntity
    {
        public Guid ProfessionId { get; set; }
        public string Profession { get; set; } = "";
    }
}